---
visible: false
content:
    items:
        '@taxonomy.category': 'docs'
    order:
        by: date
        dir: desc
---

Non-visible page for RSS feed page collection. RSS feed URL is ../feed.rss
