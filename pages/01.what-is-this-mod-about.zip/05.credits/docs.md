---
title: Credits
taxonomy:
    category:
        - docs
visible: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
---

#### Mod Authors
XCompWiz - Thank You  
CyanideX - Thank You  
HellFirePvP - Thank You  

#### Guide Contributors
Mephie/Tyith - Guide Author  
Veovis Muad'dib - Thanks for clearing up a few things about pages  
Atrius97 - King of Grammar, Editor (Note: The grammar is current for the 1.7.10-1.12.2 versions)  
IntrACate - Editor  

#### Misc
Mystcraft Discord Group - Thanks for putting up with me  
Mystcraft Wiki - Great help for instabilities  
