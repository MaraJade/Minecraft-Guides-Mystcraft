---
title: 'Mystcraft Villager'
media_order: 'villager.jpg,lecterns.jpg'
taxonomy:
    category:
        - docs
visible: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
---

These villagers can be found within the Mystcraft house in some villages. These villagers will sell you Pages, and will also sell you Sealed Notebooks. These notebooks hold a variety of random pages (about 20 different pages), and will be key when building up your collection of pages.

![](villager.jpg)

The house can also contain a few pages in the Lecterns, although there might not always be pages in there.

![](lecterns.jpg)