---
title: 'Libraries '
taxonomy:
    category:
        - docs
visible: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
---

When you travel to a new Mystcraft Dimension there is a chance that you could find a Library while exploring. These libraries are made of cobblestone (very easy to spot with a minimap) and filled with bookshelves, Lecterns and a single hidden chest, usually containing several pages and Sealed Notebooks.

Libraries are where you will find the bulk of your pages. The more Ages you explore, the more pages you will find and the more you can customize your future Ages.
