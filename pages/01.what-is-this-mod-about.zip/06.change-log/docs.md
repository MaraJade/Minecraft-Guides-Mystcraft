---
title: 'Change Log'
taxonomy:
    category:
        - docs
visible: true
twittercardoptions: summary
articleenabled: false
musiceventenabled: false
orgaenabled: false
orga:
    ratingValue: 2.5
orgaratingenabled: false
eventenabled: false
personenabled: false
restaurantenabled: false
restaurant:
    acceptsReservations: 'yes'
    priceRange: $
---

All notable changes to this guide will be documented here.


## [1.0.0] - 6-05-2019

```
- Guide Uploaded
```