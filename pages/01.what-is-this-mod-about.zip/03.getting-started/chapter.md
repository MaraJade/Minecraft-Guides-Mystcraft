---
title: 'Getting Started'
taxonomy:
    category: docs
twitterenable: true
twittercardoptions: summary
facebookenable: false
---

# Getting Started

Before getting into writing Ages and customizing them, you need to craft a few blocks. These are essential when it comes to managing pages (there are a LOT) and creating linking and descriptive books.